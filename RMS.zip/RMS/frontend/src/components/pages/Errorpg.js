import React from "react";
import { NavLink } from "react-router-dom";
import "../css/Errorpg.css";

function Errorpg() {
  return (
    <>
      <div className="content-errorpg">
        <div className="allbtn">
          <div className="hmbtn">
            <NavLink to="/">
              <button className="btn_err">Home</button>
            </NavLink>
          </div>
          <div className="cntbn">
            <NavLink to="/contact">
              <button className="btn_err">Contact Us</button>
            </NavLink>
          </div>
        </div>
      </div>
    </>
  );
}

export default Errorpg;
