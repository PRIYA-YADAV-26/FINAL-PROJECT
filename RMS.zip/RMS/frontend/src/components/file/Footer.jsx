import React from "react";
import { NavLink } from "react-router-dom";
import "../css/Footer.css";

function Footer() {
  return (
    <>
      <div className="header-foot">
        <NavLink to="/errorpg">
          <i className="fab fa-facebook-f"></i>
        </NavLink>
        <NavLink to="/errorpg">
          <i className="fab fa-twitter"></i>
        </NavLink>
        <NavLink to="/errorpg">
          <i className="fab fa-google"></i>
        </NavLink>
        <NavLink to="/errorpg">
          <i className="fab fa-instagram"></i>
        </NavLink>
        <NavLink to="/errorpg">
          <i className="fab fa-linkedin-in"></i>
        </NavLink>
        <NavLink to="/errorpg">
          <i className="fab fa-github"></i>
        </NavLink>
      </div>
      <div className="footer">
        <div className="footer-foot">
          <h5>© 2020 Copyright: SFResturants.com</h5>
        </div>
      </div>
    </>
  );
}

export default Footer;
