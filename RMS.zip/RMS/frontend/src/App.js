import React from 'react';
import Main from '../src/components/file/Main'

function App() {
  return <Main/>
}

export default App;